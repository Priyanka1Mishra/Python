from django.apps import AppConfig


class TweeappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tweeapp'
